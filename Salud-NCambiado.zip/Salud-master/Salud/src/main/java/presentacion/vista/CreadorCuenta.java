package presentacion.vista;

public interface CreadorCuenta {

	boolean obtenerCuenta(String nombre, String usuario, String pass);
	
}
