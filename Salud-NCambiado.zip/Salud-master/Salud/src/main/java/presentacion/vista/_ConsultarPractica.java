package presentacion.vista;

import java.util.List;

import dto.PracticaDTO;

public interface _ConsultarPractica {

	public void entregarPracticas(List<PracticaDTO> practicas);
	
}
