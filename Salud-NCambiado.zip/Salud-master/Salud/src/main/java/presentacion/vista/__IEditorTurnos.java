package presentacion.vista;

import javax.swing.JButton;

public interface __IEditorTurnos {

	public JButton getButtonRegistrarNuevoTurno();
	
	public JButton getButtonConsultarTurno();

	public JButton getButtonPostergarTurno();
	
	public JButton getButtonCancelarTurno();
	
}
